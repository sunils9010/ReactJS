
export const GET_MOVIE_LIST = "GET_MOVIE_LIST";
export const SEARCH_MOVIE = "SEARCH_MOVIE";